package Totolotek.Wyjatki;

public class BrakKolekturWyjatek extends Exception {
    public BrakKolekturWyjatek() {
        super("Nie istnieje żadna Kolektura");
    }
}
