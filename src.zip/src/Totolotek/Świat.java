package Totolotek;

public class Świat {
}
